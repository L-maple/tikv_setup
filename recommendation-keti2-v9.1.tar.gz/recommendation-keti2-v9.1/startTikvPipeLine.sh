java -cp target/recommendation-keti2-1.0-SNAPSHOT.jar cn.edu.neu.tiger.TikvPipeline 
